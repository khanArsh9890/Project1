const config = {
    mongoURI: 'mongodb://localhost:27017/bookDB', // Replace with your MongoDB URI
  };


  
  export default config;